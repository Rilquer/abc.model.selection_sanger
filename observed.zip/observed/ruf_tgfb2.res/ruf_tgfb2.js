
USETEXTLINKS = 1
STARTALLOPEN = 0
WRAPTEXT = 1
PRESERVESTATE = 0
HIGHLIGHT = 1
ICONPATH = 'file:////Users/Mac/OneDrive/Academy/Papers/M.%20rufiventris/Submissão/JOrnith%20Set-2018/First%20review/observed/'    //change if the gif's folder is a subfolder, for example: 'images/'

foldersTree = gFld("<i>ARLEQUIN RESULTS (ruf_tgfb2.arp)</i>", "")
insDoc(foldersTree, gLnk("R", "Arlequin log file", "Arlequin_log.txt"))
	aux1 = insFld(foldersTree, gFld("Run of 08/01/19 at 10:36:46", "ruf_tgfb2.htm#08_01_19at10_36_46"))
	insDoc(aux1, gLnk("R", "Settings", "ruf_tgfb2.htm#08_01_19at10_36_46_run_information"))
		aux2 = insFld(aux1, gFld("Shared haplotypes", "ruf_tgfb2.htm#08_01_19at10_36_46_shared%20haplotypes"))
		insDoc(aux2, gLnk("R", "North", "ruf_tgfb2.htm#08_01_19at10_36_46_gr_shared0"))
		insDoc(aux2, gLnk("R", "South", "ruf_tgfb2.htm#08_01_19at10_36_46_gr_shared1"))
		aux2 = insFld(aux1, gFld("Groups", ""))
		insDoc(aux2, gLnk("R", "Group1", "ruf_tgfb2.htm#08_01_19at10_36_46_samp0"))
		aux2 = insFld(aux1, gFld("Within-groups summary", ""))
		insDoc(aux2, gLnk("R", "Basic indices", "ruf_tgfb2.htm#08_01_19at10_36_46_gr_comp_sum_Basic"))
		insDoc(aux2, gLnk("R", "Heterozygosity", "ruf_tgfb2.htm#08_01_19at10_36_46_gr_comp_sum_het"))
		insDoc(aux2, gLnk("R", "No. of alleles", "ruf_tgfb2.htm#08_01_19at10_36_46_gr_comp_sum_numAll"))
		insDoc(aux2, gLnk("R", "Molecular diversity", "ruf_tgfb2.htm#08_01_19at10_36_46_gr_comp_sum_moldiv"))
		aux2 = insFld(aux1, gFld("Samples", ""))
		insDoc(aux2, gLnk("R", "North", "ruf_tgfb2.htm#08_01_19at10_36_46_group0"))
		insDoc(aux2, gLnk("R", "South", "ruf_tgfb2.htm#08_01_19at10_36_46_group1"))
		aux2 = insFld(aux1, gFld("Within-samples summary", ""))
		insDoc(aux2, gLnk("R", "Basic indices", "ruf_tgfb2.htm#08_01_19at10_36_46_comp_sum_Basic"))
		insDoc(aux2, gLnk("R", "Heterozygosity", "ruf_tgfb2.htm#08_01_19at10_36_46_comp_sum_het"))
		insDoc(aux2, gLnk("R", "No. of alleles", "ruf_tgfb2.htm#08_01_19at10_36_46_comp_sum_numAll"))
		insDoc(aux2, gLnk("R", "Molecular diversity", "ruf_tgfb2.htm#08_01_19at10_36_46_comp_sum_moldiv"))
